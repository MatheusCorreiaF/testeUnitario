package br.com.original.teste.testeThreadFilter.testeThreadFilter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteThreadFilterApplicationTests {

	@Test
	void contextLoads() {
	}

}
