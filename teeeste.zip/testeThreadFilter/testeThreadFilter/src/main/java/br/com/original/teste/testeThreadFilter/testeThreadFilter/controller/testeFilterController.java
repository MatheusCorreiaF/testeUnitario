package br.com.original.teste.testeThreadFilter.testeThreadFilter.controller;

import br.com.original.teste.testeThreadFilter.testeThreadFilter.service.FeignService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class testeFilterController {

    @Autowired
    private FeignService feignService;

    @GetMapping("teste/")
    public ResponseEntity<String> testeController()
    {
        return new ResponseEntity<>(feignService.callByFeign(), HttpStatus.ACCEPTED);
    }
}
