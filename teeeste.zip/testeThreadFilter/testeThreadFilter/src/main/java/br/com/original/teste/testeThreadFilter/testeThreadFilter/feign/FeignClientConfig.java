package br.com.original.teste.testeThreadFilter.testeThreadFilter.feign;

import org.springframework.context.annotation.Bean;

import feign.Feign;
import java.util.Properties;

public class FeignClientConfig {

    private Properties engineProperties;

    @Bean
    public TesteFeignClient getFeignClient() {
        return Feign.builder().target(TesteFeignClient.class, "http://localhost:8083/teste");
    }
}
