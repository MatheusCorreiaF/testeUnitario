package br.com.original.teste.testeThreadFilter.testeThreadFilter.interceptor;

import br.com.original.teste.testeThreadFilter.testeThreadFilter.wrappers.WrappedHttpServletRequest;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class InterceptorFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse httpServletResponse, FilterChain filterChain) throws ServletException, IOException {

        WrappedHttpServletRequest wrappedRequest = new WrappedHttpServletRequest(request);
        String uri = wrappedRequest.getRequestURI();
    }
}
