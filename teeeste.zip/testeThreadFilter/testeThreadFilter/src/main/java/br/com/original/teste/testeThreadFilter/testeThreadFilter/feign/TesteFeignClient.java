package br.com.original.teste.testeThreadFilter.testeThreadFilter.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;

@org.springframework.cloud.openfeign.FeignClient(name="http://localhost:8083/teste")
public interface TesteFeignClient {

        @GetMapping("/")
        public String testeController();
}
