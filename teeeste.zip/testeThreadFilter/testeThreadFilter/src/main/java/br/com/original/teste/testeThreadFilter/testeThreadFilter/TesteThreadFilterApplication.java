package br.com.original.teste.testeThreadFilter.testeThreadFilter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteThreadFilterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteThreadFilterApplication.class, args);
	}

}
