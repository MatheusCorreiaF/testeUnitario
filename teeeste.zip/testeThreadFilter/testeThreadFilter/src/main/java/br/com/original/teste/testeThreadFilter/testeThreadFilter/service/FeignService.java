package br.com.original.teste.testeThreadFilter.testeThreadFilter.service;

import br.com.original.teste.testeThreadFilter.testeThreadFilter.feign.TesteFeignClient;
import org.springframework.stereotype.Service;

@Service
public class FeignService {

    //@Autowired
    private TesteFeignClient testeFeignClient;

    public String callByFeign() {
        return testeFeignClient.testeController();
    }
}
