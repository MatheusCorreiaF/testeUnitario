package br.com.original.teste.testeThreadController.testeThreadController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteThreadControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
