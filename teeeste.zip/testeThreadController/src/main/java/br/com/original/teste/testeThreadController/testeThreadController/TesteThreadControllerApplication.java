package br.com.original.teste.testeThreadController.testeThreadController;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteThreadControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteThreadControllerApplication.class, args);
	}

}
