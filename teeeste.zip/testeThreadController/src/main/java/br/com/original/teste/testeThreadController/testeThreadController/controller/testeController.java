package br.com.original.teste.testeThreadController.testeThreadController.controller;

import br.com.original.teste.testeThreadController.testeThreadController.service.MatematicaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("")
public class testeController {

    @Autowired
    private MatematicaService matematicaService;


    @GetMapping("/teste")
    public ResponseEntity<String> testeController()
    {
        return new ResponseEntity<>(matematicaService.resultado(), HttpStatus.ACCEPTED);
    }

}
