package br.com.original.teste.testeThreadController.testeThreadController.service;

import org.springframework.stereotype.Service;

@Service
public class MatematicaService {

    public String resultado() {
        return "67";
    }
}
